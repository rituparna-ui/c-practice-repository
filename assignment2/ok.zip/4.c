#include <stdio.h>

int main()
{
    float l, w;
    printf("Enter lenght");
    scanf("%f", &l);
    printf("Enter width", &w);
    scanf("%f", &w);
    printf("The area of rectangle is %.2f", l * b);
    return 0;
}