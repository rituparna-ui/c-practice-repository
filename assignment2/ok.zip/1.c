#include <stdio.h>

int main()
{
    char a = 'a';
    printf("%d", a);
    return 0;
}